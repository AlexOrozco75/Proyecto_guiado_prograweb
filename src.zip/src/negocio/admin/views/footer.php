<footer class="bg-dark text-white text-center py-3 mt-5">
  <div class="container">
    <p class="mb-0">&copy; 2026 Mi Sitio Web. Todos los derechos reservados.</p>
  </div>
</footer>