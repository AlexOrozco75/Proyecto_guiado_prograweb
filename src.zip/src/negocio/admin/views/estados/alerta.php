<div class="alert alert-<?php echo $alerta['tipo']; ?>" role="alert">
  <?php echo $alerta['mensaje']; ?>
  
</div>