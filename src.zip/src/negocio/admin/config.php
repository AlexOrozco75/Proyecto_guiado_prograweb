<?php
define('dbdriver','mysql');
define ('dbhost','mariadb');
define('dbname', 'database');
define('dbuser','user');
define('dbpassword','password');
define('dbport','3306');

?>