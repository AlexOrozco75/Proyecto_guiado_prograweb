<?php
require_once(__DIR__."/sistema.class.php");
require_once(__dir__."/models/estado.php");
$estado = new Estado();

try{
     $estados = $estado->leerUno(2);   
    
     
        echo "ID: ".$estado['id_estado']." - Nombre: ".$estado['estado']."<br>";
     

      $data = [];
$data['estado'] = "Baja California Sur"; 
$cantidad = $estado->crear($data);
echo "Cantidad de registros afectados: " . $cantidad;
$estados = $app->leer();
include (__DIR__ . "/views/estado/index.php");
      
    
}
    catch(PDOException $e){
        echo "Error: ".$e->getMessage();

}

