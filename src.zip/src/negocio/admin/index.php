<?php
require_once('config.php');

include_once(__dir__."/views/header.php");
echo"<h1>Bienvenido al sistema</h1>";
include_once(__dir__."/views/footer.php");
?>
